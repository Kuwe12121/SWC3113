import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
// import { canActivate, redirectUnauthorizedTo, redirectLoggedInTo} from '@angular/fire/auth-guard';
import { AuthGuard } from './guards/auth.guard';


// Send unauthorized users to login
// const redirectUnauthorizedToLogin = () =>
//   redirectUnauthorizedTo(['/']);

// // Automatically log in users
// const redirectLoggedInToHome = () =>
//   redirectLoggedInTo(['/tabs']);

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',

    // loadChildren: () =>
    //   import('./pages/login/login.module').then((m) => m.LoginPageModule),
    // ...canActivate(redirectLoggedInToHome),
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./pages/login/login.module').then((m) => m.LoginPageModule),
  },
  {
    path: 'login-issue',
    loadChildren: () =>
      import('./pages/login-issue/login-issue.module').then(
        (m) => m.LoginIssuePageModule
      ),
  },
  {
    path: 'tabs',
    loadChildren: () =>
      import('./pages/tabs/tabs.module').then((m) => m.TabsPageModule),
    // ...canActivate(redirectUnauthorizedToLogin),
    canActivate: [AuthGuard],
  },
  {
    path: 'settings',
    loadChildren: () =>
      import('./pages/settings/settings.module').then(
        (m) => m.SettingsPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'chat-detail',
    loadChildren: () =>
      import('./pages/chat-detail/chat-detail.module').then(
        (m) => m.ChatDetailPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'news-detail/:id',
    loadChildren: () =>
      import('./pages/news-detail/news-detail.module').then(
        (m) => m.NewsDetailPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'profile',
    loadChildren: () =>
      import('./pages/profile/profile.module').then((m) => m.ProfilePageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'submit-news',
    loadChildren: () =>
      import('./pages/news/submit-news/submit-news.module').then(
        (m) => m.SubmitNewsPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'start-group',
    loadChildren: () =>
      import('./pages/start-group/start-group.module').then(
        (m) => m.StartGroupPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'chat-group-detail/:id',
    loadChildren: () =>
      import('./pages/chat-group-detail/chat-group-detail.module').then(
        (m) => m.ChatGroupDetailPageModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'upload',
    loadChildren: () => import('./pages/upload/upload.module').then( (m) => m.UploadPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'assignment',
    loadChildren: () => import('./pages/assignment/assignment.module').then( (m) => m.AssignmentPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'swc3113',
    loadChildren: () => import('./pages/swc3113/swc3113.module').then( m => m.Swc3113PageModule)
  },
  {
    path: 'fyp3014',
    loadChildren: () => import('./pages/fyp3014/fyp3014.module').then( m => m.Fyp3014PageModule)
  },
  {
    path: 'assignment1',
    loadChildren: () => import('./pages/assignment1/assignment1.module').then( m => m.Assignment1PageModule)
  },
  {
    path: 'upload1',
    loadChildren: () => import('./pages/upload1/upload1.module').then( m => m.Upload1PageModule)
  },
  {
    path: 'material',
    loadChildren: () => import('./pages/material/material.module').then( m => m.MaterialPageModule)
  },
  {
    path: 'material1',
    loadChildren: () => import('./pages/material1/material1.module').then( m => m.Material1PageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'loginuser',
    loadChildren: () => import('./pages/loginuser/loginuser.module').then( m => m.LoginuserPageModule)
  },
  {
    path: 'tabsuser',
    loadChildren: () => import('./pages/tabsuser/tabsuser.module').then( (m) => m.TabsuserPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'swc3113user',
    loadChildren: () => import('./pages/swc3113user/swc3113user.module').then( m => m.Swc3113userPageModule)
  },
  {
    path: 'fyp3014user',
    loadChildren: () => import('./pages/fyp3014user/fyp3014user.module').then( m => m.Fyp3014userPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
