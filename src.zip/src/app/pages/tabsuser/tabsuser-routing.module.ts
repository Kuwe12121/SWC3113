import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TabsuserPage } from './tabsuser.page';

const routes: Routes = [
  {
    path: '',
    component: TabsuserPage,
    children: [
      {
        path: 'newsuser',
        loadChildren: () =>
          import('../newsuser/newsuser.module').then((m) => m.NewsuserPageModule),
      },
      {
        path: 'chats',
        loadChildren: () =>
          import('../chats/chats.module').then((m) => m.ChatsPageModule),
      },
      {
        path: 'calendar',
        loadChildren: () =>
          import('../calendar/calendar.module').then((m) => m.CalendarPageModule),
      },
      {
        path: 'folderuser',
        loadChildren: () =>
          import('../folderuser/folderuser.module').then((m) => m.FolderuserPageModule),
      },
      {
        path: '',
        redirectTo: '/tabsuser/newsuser',
        pathMatch: 'full',
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabsuserPageRoutingModule {}
