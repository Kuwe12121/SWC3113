import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabsuser',
  templateUrl: './tabsuser.page.html',
  styleUrls: ['./tabsuser.page.scss'],
})
export class TabsuserPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
