import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewsuserPageRoutingModule } from './newsuser-routing.module';

import { NewsuserPage } from './newsuser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewsuserPageRoutingModule
  ],
  declarations: [NewsuserPage]
})
export class NewsuserPageModule {}
