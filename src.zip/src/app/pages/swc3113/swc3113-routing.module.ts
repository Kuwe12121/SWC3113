import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Swc3113Page } from './swc3113.page';

const routes: Routes = [
  {
    path: '',
    component: Swc3113Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Swc3113PageRoutingModule {}
