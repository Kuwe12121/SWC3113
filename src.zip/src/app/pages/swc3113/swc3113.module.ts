import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Swc3113PageRoutingModule } from './swc3113-routing.module';

import { Swc3113Page } from './swc3113.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Swc3113PageRoutingModule
  ],
  declarations: [Swc3113Page]
})
export class Swc3113PageModule {}
