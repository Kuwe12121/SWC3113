import { Component } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from "@angular/fire/firestore";
import { Observable } from 'rxjs';
import { AngularFireStorage } from '@angular/fire/storage';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-swc3113',
  templateUrl: 'swc3113.page.html',
  styleUrls: ['swc3113.page.scss'],
})
export class Swc3113Page {
  items: Observable<any[]>;
  cloudFiles = [];

  newTodo: string = '';
  itemsRef: AngularFirestoreCollection;

  selectedFile: any;
  loading: HTMLIonLoadingElement;

  constructor(
    private db: AngularFirestore, 
    private storage: AngularFireStorage, 
    private loadingController: LoadingController,
    ) {
    this.itemsRef = db.collection('swc')
    this.items = this.itemsRef.valueChanges();
  }

  chooseFile (event) {
    this.selectedFile = event.target.files
  }

  addTodo(){
    this.itemsRef.add({
      title: this.newTodo
    })
    .then(async resp => {

      const imageUrl = await this.uploadFile(resp.id, this.selectedFile)

      this.itemsRef.doc(resp.id).update({
        id: resp.id,
        imageUrl: imageUrl || null
      })
    }).catch(error => {
      console.log(error);
    })
  }

  async uploadFile(id, file): Promise<any> {
    if(file && file.length) {
      try {
        await this.presentLoading();
        const task = await this.storage.ref('swc').child(id).put(file[0])
        this.loading.dismiss();
        return this.storage.ref(`swc/${id}`).getDownloadURL().toPromise();
      } catch (error) {
        console.log(error);
      }
    }
  }

  async presentLoading() {
    this.loading = await this.loadingController.create({
      message: 'Please wait...'
    });
    return this.loading.present();
  }



  remove(item){
    console.log(item);
    if(item.imageUrl) {
      this.storage.ref(`swc/${item.id}`).delete()
    }
    this.itemsRef.doc(item.id).delete()
  }
}
