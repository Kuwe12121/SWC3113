import { Component, OnInit } from '@angular/core';
import { ChatService } from 'src/app/services/chat.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {

  currentUser: any

  constructor(private chatService: ChatService) { }

  ngOnInit() {
    this.currentUser = this.chatService.userData;
  }

}
