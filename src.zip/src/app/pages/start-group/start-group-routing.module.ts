import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StartGroupPage } from './start-group.page';

const routes: Routes = [
  {
    path: '',
    component: StartGroupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StartGroupPageRoutingModule {}
