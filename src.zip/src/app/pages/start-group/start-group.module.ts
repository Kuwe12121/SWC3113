import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StartGroupPageRoutingModule } from './start-group-routing.module';

import { StartGroupPage } from './start-group.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StartGroupPageRoutingModule
  ],
  declarations: [StartGroupPage]
})
export class StartGroupPageModule {}
