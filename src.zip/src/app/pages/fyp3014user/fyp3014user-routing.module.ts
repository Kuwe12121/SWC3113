import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Fyp3014userPage } from './fyp3014user.page';

const routes: Routes = [
  {
    path: '',
    component: Fyp3014userPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Fyp3014userPageRoutingModule {}
