import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Fyp3014userPageRoutingModule } from './fyp3014user-routing.module';

import { Fyp3014userPage } from './fyp3014user.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Fyp3014userPageRoutingModule
  ],
  declarations: [Fyp3014userPage]
})
export class Fyp3014userPageModule {}
