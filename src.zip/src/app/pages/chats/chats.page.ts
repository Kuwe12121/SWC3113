import { Component, OnInit } from '@angular/core';
import { ChatService } from './../../services/chat.service';
import { AuthService } from './../../services/auth.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-chats',
  templateUrl: './chats.page.html',
  styleUrls: ['./chats.page.scss'],
})
export class ChatsPage implements OnInit {
  groups: Observable<any>;
  segment = "personal";

  constructor(
    private auth: AuthService,
    private router: Router,
    private chatService: ChatService
  ) {}

  ngOnInit() {
    this.groups = this.chatService.getGroups();
  }

  openProfile() {}
}
