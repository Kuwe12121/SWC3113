import { Component, OnInit } from '@angular/core';

import { ThemeService } from 'src/app/services/theme.service';
import { Router } from '@angular/router';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { ChatService } from 'src/app/services/chat.service';
import { AuthService } from './../../services/auth.service';
import { AngularFireAuth } from '@angular/fire/auth';


@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {
  darkModeState: boolean;
  currentUser = this.chatService.userData;
  // currentUser2: any;

  constructor(
    private themeService: ThemeService,
    private chatService: ChatService,
    private afAuth: AngularFireAuth,
    private router: Router,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController,
    private auth: AuthService
  ) {
    this.darkModeState = this.themeService.getDarkMode;
  }

  ngOnInit() {
    // this.currentUser2 = this.auth.currentUser;
    // console.log(this.currentUser2);
    // this.currentUser = this.chatService.userData;
  }

  toggleDarkMode() {
    this.themeService.toggleAppTheme();
    this.darkModeState = this.themeService.getDarkMode;
  }

  async signOut() {
    const loading = await this.loadingCtrl.create({
      message: 'Signing out...',
    });
    await loading.present();

    await this.auth.signOut().then((res) => {
      loading.dismiss();
      this.router.navigateByUrl('/home');
    });
  }

  async changePasswordAlert() {
    const alert = await this.alertCtrl.create({
      header: 'Enter the new password',
      message:
        "Your new password should be at least 6 characters. Once confirmed you'll be able to use the new password.",
      inputs: [
        {
          name: 'newPassword1',
          type: 'password',
          placeholder: 'New password',
        },
        {
          name: 'newPassword2',
          type: 'password',
          placeholder: 'Confirm new password',
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
        },
        {
          text: 'Confirm',
          handler: (alertData) => {
            if (
              alertData.newPassword1 == alertData.newPassword2 &&
              alertData.newPassword1 != '' &&
              alertData.newPassword2 != ''
            ) {
              this.changePassword(alertData.newPassword2);
            } else {
              this.showToast('Error: Please retype your new password!');
            }
          },
        },
      ],
    });
    await alert.present();
  }

  async changePassword(newPassword: string) {
    try {
      (await this.afAuth.currentUser)
        .updatePassword(newPassword)
        .then(() => this.showToast('Password successfully changed!'));
    } catch (e) {
      this.showToast(e);
      console.log(e);
    }
  }

  showToast(message: string) {
    this.toastCtrl
      .create({
        message: message,
        duration: 3000,
      })
      .then((toastData) => toastData.present());
  }
}
