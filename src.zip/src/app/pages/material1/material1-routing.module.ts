import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Material1Page } from './material1.page';

const routes: Routes = [
  {
    path: '',
    component: Material1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Material1PageRoutingModule {}
