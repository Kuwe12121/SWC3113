import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Material1PageRoutingModule } from './material1-routing.module';

import { Material1Page } from './material1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Material1PageRoutingModule
  ],
  declarations: [Material1Page]
})
export class Material1PageModule {}
