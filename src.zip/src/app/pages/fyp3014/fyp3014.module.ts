import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Fyp3014PageRoutingModule } from './fyp3014-routing.module';

import { Fyp3014Page } from './fyp3014.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Fyp3014PageRoutingModule
  ],
  declarations: [Fyp3014Page]
})
export class Fyp3014PageModule {}
