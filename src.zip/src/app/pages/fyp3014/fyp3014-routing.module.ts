import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Fyp3014Page } from './fyp3014.page';

const routes: Routes = [
  {
    path: '',
    component: Fyp3014Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Fyp3014PageRoutingModule {}
