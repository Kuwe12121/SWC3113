import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LoginuserPageRoutingModule } from './loginuser-routing.module';

import { LoginuserPage } from './loginuser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LoginuserPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [LoginuserPage]
})
export class LoginuserPageModule {}
