import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Upload1PageRoutingModule } from './upload1-routing.module';

import { Upload1Page } from './upload1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Upload1PageRoutingModule
  ],
  declarations: [Upload1Page]
})
export class Upload1PageModule {}
