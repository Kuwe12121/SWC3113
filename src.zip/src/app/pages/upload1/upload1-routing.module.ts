import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Upload1Page } from './upload1.page';

const routes: Routes = [
  {
    path: '',
    component: Upload1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Upload1PageRoutingModule {}
