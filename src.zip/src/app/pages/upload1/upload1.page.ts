import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload1',
  templateUrl: './upload1.page.html',
  styleUrls: ['./upload1.page.scss'],
})
export class Upload1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
