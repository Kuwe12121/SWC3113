import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FolderuserPageRoutingModule } from './folderuser-routing.module';

import { FolderuserPage } from './folderuser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FolderuserPageRoutingModule
  ],
  declarations: [FolderuserPage]
})
export class FolderuserPageModule {}
