import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { AngularFirestore, AngularFirestoreCollection } from "@angular/fire/firestore";
import { Observable } from 'rxjs';
import { AngularFireStorage } from '@angular/fire/storage';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-folderuser',
  templateUrl: 'folderuser.page.html',
  styleUrls: ['folderuser.page.scss'],
})
export class FolderuserPage {

  constructor(private navCtrl:NavController){

  }


  ngOnInit() {
  }

  gotoSwc(){
    this.navCtrl.navigateForward('/swc3113user')

  }

  gotoFyp(){
    this.navCtrl.navigateForward('/fyp3014user')

  }
}
