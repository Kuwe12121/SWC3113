import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FolderuserPage } from './folderuser.page';

const routes: Routes = [
  {
    path: '',
    component: FolderuserPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FolderuserPageRoutingModule {}
