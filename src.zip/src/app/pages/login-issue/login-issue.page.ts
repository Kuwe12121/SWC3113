import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-login-issue',
  templateUrl: './login-issue.page.html',
  styleUrls: ['./login-issue.page.scss'],
})
export class LoginIssuePage implements OnInit {
  private email: string;

  constructor(
    private alertCtrl: AlertController, 
    private afAuth: AngularFireAuth) {}

  ngOnInit() {}

  async sendEmail() {
    if (this.email) {
      const alert = await this.alertCtrl.create({
        header: 'Confirm submission?',
        message:
          'Once confirmed an email will be sent to you. Check your inbox and follow the guide to reset the password.',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
          },
          {
            text: 'Confirm',
            handler: () => {
              this.afAuth.sendPasswordResetEmail(this.email).then(
                (res) => {
                  this.showAlert('Submission successful', 'An email has been sent to you!');
                  
                },
                (error) => {
                  this.showAlert('Submission failed', error.message);
                }
              );
            },
          },
        ],
      });

      await alert.present();
    } else {
      this.showAlert('Error', 'Please enter your email');
    }
  }

  async showAlert(header: string, message: string) {
    const alert = await this.alertCtrl.create({
      header: header,
      message: message,
      buttons: ['OK'],
    });
    
    await alert.present();
  }
}
