import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Swc3113userPageRoutingModule } from './swc3113user-routing.module';

import { Swc3113userPage } from './swc3113user.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Swc3113userPageRoutingModule
  ],
  declarations: [Swc3113userPage]
})
export class Swc3113userPageModule {}
