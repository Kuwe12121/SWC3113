import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Swc3113userPage } from './swc3113user.page';

const routes: Routes = [
  {
    path: '',
    component: Swc3113userPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Swc3113userPageRoutingModule {}
