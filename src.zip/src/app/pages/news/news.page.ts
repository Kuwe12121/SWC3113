import { Component, OnInit, Query } from '@angular/core';

import { AngularFirestore } from '@angular/fire/firestore';
import { PopoverController, LoadingController, ToastController} from '@ionic/angular';
import { PopoverComponent } from 'src/app/components/popover/popover.component';
import { ChatService } from 'src/app/services/chat.service';

@Component({
  selector: 'app-news',
  templateUrl: './news.page.html',
  styleUrls: ['./news.page.scss'],
})
export class NewsPage implements OnInit {
  news: any;

  constructor(
    private afs: AngularFirestore,
    private chatService: ChatService,
    private popoverCtrl: PopoverController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController
  ) {}

  ngOnInit() {}

  ionViewWillEnter() {
    this.getNews();
  }

  async getNews() {
    let loader = await this.loadingCtrl.create({
      message: 'Please wait...',
    });
    loader.present();

    try {
      this.afs
        .collection('news', ref =>
        ref.orderBy('createdAt', 'desc'))
        .snapshotChanges()
        .subscribe((data) => {
          this.news = data.map((e) => {
            return {
              id: e.payload.doc.id,
              content: e.payload.doc.data()['content'],
              title: e.payload.doc.data()['title'],
              createdAt: e.payload.doc.data()['createdAt'],
              from: e.payload.doc.data()['from'],
            };
          });
          loader.dismiss();
        });
    } catch (e) {
      this.showToast(e);
    }
  }

  async showPopover(ev: any) {
    const popover = await this.popoverCtrl.create({
      component: PopoverComponent,
      event: ev,
    });
    await popover.present();
  }

  showToast(message: string) {
    this.toastCtrl
      .create({
        message: message,
        duration: 3000,
      })
      .then((toastData) => toastData.present());
  }
}
