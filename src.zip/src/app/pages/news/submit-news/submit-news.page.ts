import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AngularFirestore } from '@angular/fire/firestore';
import firebase from 'firebase/app';
import { ChatService } from 'src/app/services/chat.service';
import { LoadingController, NavController, ToastController, } from '@ionic/angular';

@Component({
  selector: 'app-submit-news',
  templateUrl: './submit-news.page.html',
  styleUrls: ['./submit-news.page.scss'],
})
export class SubmitNewsPage implements OnInit {
  newsForm: FormGroup;
  currentUser: any;
  // date: firebase.firestore.FieldValue;

  constructor(
    private fb: FormBuilder,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private navCtrl: NavController,
    private chatService: ChatService,
    private afs: AngularFirestore
  ) {}

  ngOnInit() {
    this.currentUser = this.chatService.userData;
    this.newsForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(50)]],
      // createdAt: [
      //   `${firebase.firestore.FieldValue.serverTimestamp()}`,
      //   [Validators.required],
      // ],
      content: ['', [Validators.required, Validators.maxLength(100)]],
    });

    // this.newsForm.controls['newsForm'].setValue(firebase.firestore.FieldValue);
  }

  async submitNews() {
    //show loader
    let loader = this.loadingCtrl.create({
      message: 'Please wait...',
    });
    (await loader).present();

    // try {
    await this.afs
      .collection('news')
      .add(this.newsForm.value)
      .then(
        (res) => {
          //add created date
          this.afs.doc("news/" + res.id).update({
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            from: this.chatService.currentUser.uid
          });
          this.showToast('The report has been submitted.');
        },
        (e) => {
          this.showToast(e);
        }
      );

    //dismiss loader
    (await loader).dismiss();

    //redirect to previous page
    this.navCtrl.navigateRoot('tabs/news');

    // } catch (e) {
    //   this.showToast(e);
    // }
  }

  showToast(message: string) {
    this.toastCtrl
      .create({
        message: message,
        duration: 3000,
      })
      .then((toastData) => toastData.present());
  }
}
