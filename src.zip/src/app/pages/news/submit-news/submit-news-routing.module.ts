import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SubmitNewsPage } from './submit-news.page';

const routes: Routes = [
  {
    path: '',
    component: SubmitNewsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SubmitNewsPageRoutingModule {}
