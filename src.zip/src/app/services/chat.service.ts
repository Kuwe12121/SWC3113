import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireStorage, AngularFireStorageReference } from '@angular/fire/storage';
import * as firebase from 'firebase/app';
import { forkJoin, from } from 'rxjs';
import { switchMap, map, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

//for logging in
export interface User {
  uid: string;
  email: string;
  displayName: string;

}

//for displaying current user on any page
export interface CurrentUser {
  uid: string;
  email: string;
  nickname: string;
  displayName: string;
  role: string;
  status: string;
  courseCode: string;
  photoURL: string;
}

//for chat functions
export interface Message {
  createdAt: firebase.default.firestore.FieldValue;
  id: string;
  from: string;
  msg: string;
  fromName: string;
  myMsg: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class ChatService {
  currentUser: User = null;
  userData = {} as CurrentUser;
  // currentUser2: any;

  constructor(
    private afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private auth: AuthService,
    private storage: AngularFireStorage
  ) {
    this.afAuth.onAuthStateChanged((user) => {
      console.log('Changed: ', user);
      if (user) {
        this.currentUser = user;
        this.getCurrentUser();
        // this.currentUser2 = auth.user;
      } else {
        console.log('Not logged in');
      }
    });
  }

  //for displaying current user on any page
  getCurrentUser() {
    this.afs
      .doc('users/' + this.currentUser.uid)
      .valueChanges()
      .subscribe((data) => {
        this.userData.email = data['email'];
        this.userData.uid = data['uid'];
        this.userData.status = data['status'];
        this.userData.role = data['role'];
        this.userData.nickname = data['nickname'];
        this.userData.displayName = data['displayName'];
        this.userData.courseCode = data['courseCode'];
        this.userData.photoURL = data['photoURL'];
      });
  }

   async signUp({ email, password}) {
     const credential = await this.afAuth.createUserWithEmailAndPassword(
       email,
       password
     );

     console.log('result: ', credential);
     const uid = credential.user.uid;

     return this.afs.doc(`users/${uid}`).set({
       uid,
       email: credential.user.email,
     });
   }

   signIn({ email, password }) {
     return this.afAuth.signInWithEmailAndPassword(email, password);
   }

   signOut() {
     return this.afAuth.signOut();
  }

  //=================================For group chat functions========================================

  findUser(value) {
    let email = this.afs
      .collection('users', (ref) => ref.where('email', '==', value))
      .snapshotChanges()
      .pipe(
        take(1),
        map((actions) =>
          actions.map((a) => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...(data as Object) };
          })
        )
      );
    let nickname = this.afs
      .collection('users', (ref) => ref.where('nickname', '==', value))
      .snapshotChanges()
      .pipe(
        take(1),
        map((actions) =>
          actions.map((a) => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...(data as Object) };
          })
        )
      );
    return [email, nickname];
  }

  createGroup(title, users) {
    let current = {
      email: this.auth.currentUser.email,
      id: this.auth.currentUserId,
      nickname: this.auth.nickname,
    };

    let allUsers = [current, ...users];
    return this.afs
      .collection('groups')
      .add({
        title: title,
        users: allUsers,
      })
      .then((res) => {
        let promises = [];

        for (let usr of allUsers) {
          let oneAdd = this.afs.collection(`users/${usr.id}/groups`).add({
            id: res.id,
          });
          promises.push(oneAdd);
        }
        return Promise.all(promises);
      });
  }

  getGroups() {
    return this.afs
      .collection(`users/${this.auth.currentUserId}/groups`)
      .snapshotChanges()
      .pipe(
        map((actions) =>
          actions.map((a) => {
            const data = a.payload.doc.data();
            const user_group_key = a.payload.doc.id;
            return this.getOneGroup(data['id'], user_group_key);
          })
        )
      );
  }

  getOneGroup(id, user_group_key = null) {
    return this.afs
      .doc(`groups/${id}`)
      .snapshotChanges()
      .pipe(
        take(1),
        map((changes) => {
          const data = changes.payload.data();
          const group_id = changes.payload.id;
          return { user_group_key, id: group_id, ...(data as Object) };
        })
      );
  }

  getChatMessages(groupId) {
    return this.afs
      .collection(`groups/${groupId}/messages`, (ref) =>
        ref.orderBy('createdAt')
      )
      .snapshotChanges()
      .pipe(
        map((actions) =>
          actions.map((a) => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...(data as Object) };
          })
        )
      );
  }

  addChatMessage(msg, chatId) {
    return this.afs.collection('groups/' + chatId + '/messages').add({
      msg: msg,
      from: this.auth.currentUserId,
      createdAt: firebase.default.firestore.FieldValue.serverTimestamp(),
    });
  }

  addFileMessage(file, chatId) {
    let newName = `${new Date().getTime()}-${this.auth.currentUserId}.png`;
    let storageRef: AngularFireStorageReference = this.storage.ref(
      `/files/${chatId}/${newName}`
    );
    return {
      task: storageRef.putString(file, 'base64', { contentType: 'image/png' }),
      ref: storageRef,
    };
  }

  saveFileMessage(filepath, chatId) {
    return this.afs.collection('groups/' + chatId + '/messages').add({
      file: filepath,
      from: this.auth.currentUserId,
      createdAt: firebase.default.firestore.FieldValue.serverTimestamp(),
    });
  }

  leaveGroup(groupId, users) {
    return this.getGroups().pipe(
      switchMap((userGroups) => {
        return forkJoin(userGroups);
      }),
      map((data) => {
        let toDelete = null;

        for (let group of data) {
          if (group.id == groupId) {
            toDelete = group.user_group_key;
          }
        }
        return toDelete;
      }),
      switchMap((deleteId) => {
        return from(
          this.afs
            .doc(`users/${this.auth.currentUserId}/groups/${deleteId}`)
            .delete()
        );
      }),
      switchMap(() => {
        return from(
          this.afs.doc(`groups/${groupId}`).update({
            users: users,
          })
        );
      })
    );
  }

  //=================================For personal chat functions========================================
  addPersonalMessage(msg) {
    return this.afs.collection('messages').add({
      msg,
      from: this.currentUser.uid,
      createdAt: firebase.default.firestore.FieldValue.serverTimestamp(),
    });
  }

  getPersonalMessages() {
    let users = [];

    return this.getUsers().pipe(
      switchMap((res) => {
        users = res;
        console.log('all users: ', users);
        return this.afs
          .collection('messages', (ref) => ref.orderBy('createdAt'))
          .valueChanges({ idField: 'id' }) as Observable<Message[]>;
      }),
      map((messages) => {
        for (let m of messages) {
          m.fromName = this.getUserForMsg(m.from, users);
          m.myMsg = this.currentUser.uid === m.from;
        }
        console.log('all messages: ', messages);
        return messages;
      })
    );
  }

  getUsers() {
    return this.afs
      .collection('users')
      .valueChanges({ idField: 'uid' }) as Observable<User[]>;
  }

  getUserForMsg(msgFromId, users: User[]): string {
    for (let usr of users) {
      if (usr.uid == msgFromId) {
        return usr.displayName;
      }
    }
    return 'Deleted';
  }
}
