import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';

const THEME_KEY = 'selected-app-theme';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  private _storage: Storage | null = null;
  darkMode = false;

  constructor(private plt: Platform, private storage: Storage) {

    this.plt.ready().then(() => {
      
      this.init();

      //change the theme based on the system theme settings (auto dark mode)
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
      prefersDark.addEventListener('change', (e) => {
        // console.log('matches:', e);
        this.setAppTheme(e.matches);
      });
    });
  }

  async init() {
    //creating the storage
    const storage = await this.storage.create();
    this._storage = storage;

    //get the boolean value from the local storage and set the theme
    this._storage.get(THEME_KEY).then((theme) => {
      this.setAppTheme(theme);
    });
  }

  toggleAppTheme() {
    this.darkMode = !this.darkMode;
    this.setAppTheme(this.darkMode);
  }

  async setAppTheme(dark) {
    this.darkMode = dark;
    if (this.darkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }

    //save the boolean value into local storage
    await this._storage?.set(THEME_KEY, this.darkMode);
  }

  get getDarkMode() {
    return this.darkMode;
  }
}
