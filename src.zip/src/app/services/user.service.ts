import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';


export interface User {
  uid: string;
  email: string;
  displayName: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  private userData = [];
  userDoc: AngularFirestoreDocument<User>;
  user: Observable<User>

  constructor(private afs: AngularFirestore, private afAuth: AngularFireAuth) {
  }

  async getCurrentUser() {
    const userid = (await this.afAuth.currentUser).uid;
    this.userDoc = this.afs.doc('users/' + userid);
    this.user = this.userDoc.valueChanges( { idField: 'id'} );
    console.log(this.user);
  }

  setData(id: string, data: any) {
    this.userData[id] = data;
  }

  getData(id: string) {
    return this.userData[id];
  }

}
