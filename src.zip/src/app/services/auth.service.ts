import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
// import { User } from 'firebase';
import { AngularFirestore } from '@angular/fire/firestore';
import * as firebase from 'firebase/app';
import 'firebase/firestore';
import { take, map, tap } from 'rxjs/operators';

//for sign up
export interface UserCredentials {
  email: string;
  password: string;
}

//for current user
export interface User {
  uid: string;
  email: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user: User = null;
  nickname = '';
  // status = '';

  //get the current user info from db
  constructor(private afAuth: AngularFireAuth, private afs: AngularFirestore) {
    this.afAuth.authState.subscribe((res) => {
      this.user = res;
      if (this.user) {
        console.log('authenticated user: ', this.user);
        this.afs
          .doc(`users/${this.currentUserId}`)
          .valueChanges()
          .pipe(
            tap((res) => {
              this.nickname = res['nickname'];
              // this.status = res['status'];
            })
          )
          .subscribe();
      }
    });
  }

  signUp(credentials: UserCredentials) {
    return this.afAuth
      .createUserWithEmailAndPassword(credentials.email, credentials.password)
      .then((data) => {
        return this.afs.doc(`users/${data.user.uid}`).set({
          email: data.user.email,
          created: firebase.default.firestore.FieldValue.serverTimestamp(),
        });
      });
  }

  isNicknameAvailable(name) {
    return this.afs
      .collection('users', (ref) => ref.where('nickname', '==', name).limit(1))
      .valueChanges()
      .pipe(
        take(1),
        map((user) => {
          return user;
        })
      );
  }

  signIn(credentials: UserCredentials) {
    return this.afAuth.signInWithEmailAndPassword(
      credentials.email,
      credentials.password
    );
  }

  signOut() {
    return this.afAuth.signOut();
  }

  resetPw(email) {
    return this.afAuth.sendPasswordResetEmail(email);
  }

  updateUser(nickname) {
    return this.afs.doc(`users/${this.currentUserId}`).update({
      nickname,
    });
  }

  get authenticated(): boolean {
    return this.user !== null;
  }

  get currentUser(): any {
    return this.authenticated ? this.user : null;
  }

  get currentUserId(): string {
    return this.authenticated ? this.user.uid : '';
  }
}
